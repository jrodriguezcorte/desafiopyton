"""
# Código mediante el uso de while
i = 0
while i < 50:
    print("Iteración {}".format(i + 1))
    i +=1
"""

# Código mediante el uso de for
# Entrada: <vacio>
# Salida: Imprime el valor de cada iteracion

i = 0

for i in range(50):
    # imprimendo los elementos del for desde 1 hasta 50
    print("Iteración {}".format(i + 1))
